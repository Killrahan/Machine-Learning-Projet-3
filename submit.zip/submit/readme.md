# README

## Code structure

For each of the different aspects presented in the report, we have created a python file that solves the problem according to the corresponding method. 

The corresponding files are referenced in the report in the section titles. 

In each file, at the beginning, is a summary of what the file does

### CSV_Diff

The file named csv_diff.py is used to compute the difference between two CSV files.

### Jupyter notebook

As stated in the report, to avoid having to rebuild the same dataset multiple times in case of errors, we used a jupyter notebook for the model selection part of the report (model_selection.ipynb)

## Competition

During the competition, we made modification to the file Resolve.py. The present version is the one used to get our final score in the competition. 
